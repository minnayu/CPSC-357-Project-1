//: # Pseudocode
/*:
 * Function that returns a boolean with a removed local parameter
 * Parameter: removed local parameter "number" of type Int
 * Function checks if number is greater than one and is not evenly divisible by any number ranging from 2 to the inputted number
 * Returns the boolean that is resulted from && both statements
 */
func isPrime(_ number: Int) -> Bool {
    //: checks if number is greater than one and is not evenly divisible by numbers in range of 2 and the inputted number
    return number > 1 && !(2..<number).contains {number % $0 == 0}
    //: returns boolean value
}

isPrime(2)
isPrime(3)
isPrime(10)
isPrime(13)
